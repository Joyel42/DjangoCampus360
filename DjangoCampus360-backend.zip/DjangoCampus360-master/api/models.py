from django.db import models

class Student(models.Model):
    token_no = models.CharField(max_length=10, primary_key=True)
    student_name = models.CharField(max_length=255)
    course = models.CharField(max_length=4)
    section = models.CharField(max_length=1)

    def __str__(self):
        return self.student_name


class Attendance(models.Model):
    token_no = models.OneToOneField(Student, on_delete=models.CASCADE, primary_key=True)
    date = models.DateField()
    first_in_time = models.TimeField()
    last_out_time = models.TimeField()

    def __str__(self):
        return str(self.token_no)


class Marks(models.Model):
    token_no = models.OneToOneField(Student, on_delete=models.CASCADE, primary_key=True)
    first_inter = models.IntegerField()
    second_inter = models.IntegerField()
    sem_marks = models.IntegerField()
    backlogs = models.IntegerField()
    total_percentage = models.DecimalField(max_digits=5, decimal_places=2)

    def __str__(self):
        return str(self.token_no)
