from rest_framework import serializers
from .models import Student, Attendance, Marks

class StudentSerializer(serializers.ModelSerializer):
    class Meta:
        model = Student
        fields = ['token_no', 'student_name', 'course', 'section']


class AttendanceSerializer(serializers.ModelSerializer):
    student = StudentSerializer()

    class Meta:
        model = Attendance
        fields = ['student', 'date', 'first_in_time', 'last_out_time']


class MarksSerializer(serializers.ModelSerializer):
    tk_no = StudentSerializer()

    class Meta:
        model = Marks
        fields = ['tk_no', 'first_inter', 'second_inter', 'sem_marks', 'backlogs', 'total_percentage']
