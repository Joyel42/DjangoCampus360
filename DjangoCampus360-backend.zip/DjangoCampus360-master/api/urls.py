from django.urls import path
from .views import (
    AttendanceExcelUploadAPIView,
    AttendanceExcelDataAPIView,
    AcademicsExcelUploadAPIView,
    AcademicsExcelDataAPIView,
)

urlpatterns = [
    path('api/attendance-excel-upload/', AttendanceExcelUploadAPIView.as_view(), name='attendance-excel-upload'),
    path('api/attendance-excel-data/', AttendanceExcelDataAPIView.as_view(), name='attendance-excel-data'),
    path('api/academics-excel-upload/', AcademicsExcelUploadAPIView.as_view(), name='academics-excel-upload'),
    path('api/academics-excel-data/', AcademicsExcelDataAPIView.as_view(), name='academics-excel-data'),
]
