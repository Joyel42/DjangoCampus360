import os
from openpyxl import load_workbook
from rest_framework.views import APIView
from rest_framework.response import Response

class AttendanceExcelUploadAPIView(APIView):
    def post(self, request):
        if request.FILES.get('file'):
            uploaded_file = request.FILES['file']
            
            # Specify the directory to save the uploaded Excel files for attendance
            excel_dir = 'path/to/attendance/excel/folder'
            
            # Save the uploaded file in the specified directory
            file_path = os.path.join(excel_dir, uploaded_file.name)
            with open(file_path, 'wb') as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)
            
            return Response({'success': 'Attendance file uploaded successfully.'})
        
        return Response({'error': 'Invalid request.'}, status=400)


class AttendanceExcelDataAPIView(APIView):
    def get(self, request):
        # Specify the directory where the Excel files for attendance are stored
        excel_dir = 'path/to/attendance/excel/folder'
        
        # Get the list of all Excel files in the directory
        excel_files = [f for f in os.listdir(excel_dir) if f.endswith('.xlsx')]
        
        data = []
        
        # Process each Excel file for attendance
        for excel_file in excel_files:
            file_path = os.path.join(excel_dir, excel_file)
            
            # Load the Excel file
            workbook = load_workbook(file_path)
            sheet = workbook.active
            
            # Extract data from the Excel file for attendance
            # Customize this section according to your data extraction needs
            
            # For example, assuming the data is in column B (starting from row 2)
            column_b_data = [cell.value for cell in sheet['B'][1:]]
            
            # Add the extracted data to the response
            data.append({
                'filename': excel_file,
                'data': column_b_data,
            })
        
        return Response(data)


class AcademicsExcelUploadAPIView(APIView):
    def post(self, request):
        if request.FILES.get('file'):
            uploaded_file = request.FILES['file']
            
            # Specify the directory to save the uploaded Excel files for academics
            excel_dir = 'path/to/academics/excel/folder'
            
            # Save the uploaded file in the specified directory
            file_path = os.path.join(excel_dir, uploaded_file.name)
            with open(file_path, 'wb') as destination:
                for chunk in uploaded_file.chunks():
                    destination.write(chunk)
            
            return Response({'success': 'Academics file uploaded successfully.'})
        
        return Response({'error': 'Invalid request.'}, status=400)


class AcademicsExcelDataAPIView(APIView):
    def get(self, request):
        # Specify the directory where the Excel files for academics are stored
        excel_dir = 'path/to/academics/excel/folder'
        
        # Get the list of all Excel files in the directory
        excel_files = [f for f in os.listdir(excel_dir) if f.endswith('.xlsx')]
        
        data = []
        
        # Process each Excel file for academics
        for excel_file in excel_files:
            file_path = os.path.join(excel_dir, excel_file)
            
            # Load the Excel file
            workbook = load_workbook(file_path)
            sheet = workbook.active
            
            # Extract data from the Excel file for academics
            # Customize this section according to your data extraction needs
            
            # For example, assuming the data is in column C (starting from row 2)
            column_c_data = [cell.value for cell in sheet['C'][1:]]
            
            # Add the extracted data to the response
            data.append({
                'filename': excel_file,
                'data': column_c_data,
            })
        
        return Response(data)
