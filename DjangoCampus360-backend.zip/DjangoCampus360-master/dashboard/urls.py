from django.contrib import admin  
from django.urls import path  
from dashboard import views  
from django.http import HttpResponse
from django.shortcuts import render

def my_custom_page_not_found_view(request, exception):
    return render(request, '404.html', status=404)


urlpatterns = [  
    path('',views.home),
    path('home',views.home, name="home"),
    path('login',views.LoginView, name="login"),
    path('daily-report',views.daily_report , name="daily-report"),
    path('charts',views.charts , name="charts"),
    path('history/',views.history , name="history"),
    path('logout',views.logoutPage , name="logout"),
    path('academics/',views.academics,name="academics"),
    path('excelupload/',views.excelupload,name="excelupload"),
    ]

