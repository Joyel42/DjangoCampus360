from django.conf import settings
from django.shortcuts import redirect, render
import requests
from datetime import date,datetime
import requests
from django.contrib import messages
from django.template import RequestContext
from django.http import HttpResponse,JsonResponse
from .forms import NewUserForm
from django.contrib.auth import login,authenticate,logout
from django.contrib.auth.decorators import login_required
from django.contrib.auth.models import User
from api.models import Attendance

def my_custom_page_not_found_view(request, exception):
    return render(request, '404.html', status=404)


@login_required(login_url='/login')
def home(request):
    user = request.user
    context = {'user': user}
    return render(request, 'index.html', context)

def LoginView(request):
    if request.method == 'POST':
        name = request.POST.get('username')
        passwd = request.POST.get('password')
        User = authenticate(request, username=name, password=passwd)
        if User is not None:
            login(request, User)
            return redirect('home')
    return render(request, "login.html")

@login_required(login_url='/login')
def daily_report(request):
    today = date.today()
    attendance = Attendance.objects.filter(date=today)
    students = {
        'attendance': attendance,
    }
    return render(request, 'dailyreports.html', students)

@login_required(login_url='/login')
def charts(request):
    user = request.user
    context = {'user': user}
    return render(request,'charts.html', context)

def logoutPage(request):
    logout(request)
    return redirect('home')

@login_required(login_url='/login')
def history(request):
    if request.method == 'POST':
        date_str = request.POST.get('date')  # Assuming the date is submitted via a form field named 'date'
        try:
            selected_date = datetime.strptime(date_str, '%Y-%m-%d').date()
            attendance = Attendance.objects.filter(date=selected_date)
            students = {
                'attendance': attendance,
                'selected_date': selected_date,
            }
            return render(request, 'history.html', students)
        except ValueError:
            error_message = 'Invalid date format. Please provide the date in the format YYYY-MM-DD.'
            return render(request, 'error_template.html', {'error_message': error_message})
    return render(request, 'history.html')


def get_today_attendance(request):
    today = date.today()
    attendance = Attendance.objects.filter(date=today)
    data = {
        'attendance': list(attendance.values()),
    }
    return JsonResponse(data)

   
def academics(request):
    return render(request,'academics.html')

def excelupload(request):
    return render(request,'test.html')
